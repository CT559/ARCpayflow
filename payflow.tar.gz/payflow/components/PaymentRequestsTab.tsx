"use client";

import { useState, useEffect, useCallback } from "react";
import TxStatus from "./TxStatus";

interface PaymentRequest {
  id: string;
  to: string;
  amount: string;
  token: string;
  memo: string;
  created: number;
  status: "pending" | "paid";
  txHash?: string;
  link: string;
}

const ARC_RPC = "https://rpc.arc-testnet.caldera.dev";
const USDC_ARC = "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238"; // placeholder USDC on Arc
const ARC_CHAIN_ID = 2818;

interface Props {
  walletAddress: string | null;
}

export default function PaymentRequestsTab({ walletAddress }: Props) {
  const [requests, setRequests] = useState<PaymentRequest[]>([]);
  const [form, setForm] = useState({ to: "", amount: "0.01", memo: "" });
  const [creating, setCreating] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [txStatus, setTxStatus] = useState<{ id: string; status: "pending" | "success" | "error"; hash?: string } | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem("payflow_requests");
    if (saved) {
      try { setRequests(JSON.parse(saved)); } catch {}
    }
  }, []);

  const save = (reqs: PaymentRequest[]) => {
    setRequests(reqs);
    localStorage.setItem("payflow_requests", JSON.stringify(reqs));
  };

  const createRequest = () => {
    if (!form.to || !form.amount) return;
    const id = Math.random().toString(36).slice(2, 10).toUpperCase();
    const link = `${window.location.origin}/pay?to=${encodeURIComponent(form.to)}&amount=${form.amount}&token=USDC&memo=${encodeURIComponent(form.memo)}&id=${id}`;
    const req: PaymentRequest = {
      id,
      to: form.to,
      amount: form.amount,
      token: "USDC",
      memo: form.memo,
      created: Date.now(),
      status: "pending",
      link,
    };
    save([req, ...requests]);
    setForm({ to: "", amount: "0.01", memo: "" });
    setShowCreate(false);
  };

  const copyLink = (req: PaymentRequest) => {
    navigator.clipboard.writeText(req.link);
    setCopiedId(req.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const checkOnChain = useCallback(async (req: PaymentRequest) => {
    setTxStatus({ id: req.id, status: "pending" });
    try {
      // Query recent transfer events to req.to on Arc Testnet
      const res = await fetch(ARC_RPC, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          jsonrpc: "2.0",
          id: 1,
          method: "eth_getBlockByNumber",
          params: ["latest", false],
        }),
      });
      const data = await res.json();
      if (data.result) {
        // Simulate: check for any payment by querying tx list
        // In production, would filter Transfer events by ERC-20 contract
        const mockFound = Math.random() > 0.5; // demo mode
        if (mockFound) {
          const mockHash = "0x" + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join("");
          const updated = requests.map((r) =>
            r.id === req.id ? { ...r, status: "paid" as const, txHash: mockHash } : r
          );
          save(updated);
          setTxStatus({ id: req.id, status: "success", hash: mockHash });
        } else {
          setTxStatus({ id: req.id, status: "error" });
          setTimeout(() => setTxStatus(null), 3000);
        }
      }
    } catch (e) {
      setTxStatus({ id: req.id, status: "error" });
      setTimeout(() => setTxStatus(null), 3000);
    }
  }, [requests]);

  const sendPayment = async (req: PaymentRequest) => {
    if (!(window as any).ethereum) {
      alert("Please connect MetaMask to send payments");
      return;
    }
    setTxStatus({ id: req.id, status: "pending" });
    try {
      const eth = (window as any).ethereum;
      // ERC-20 transfer encode: transfer(address,uint256)
      const selector = "0xa9059cbb";
      const paddedTo = req.to.replace("0x", "").padStart(64, "0");
      const amount = BigInt(Math.floor(parseFloat(req.amount) * 1e6)); // USDC 6 decimals
      const paddedAmount = amount.toString(16).padStart(64, "0");
      const data = selector + paddedTo + paddedAmount;

      const tx = await eth.request({
        method: "eth_sendTransaction",
        params: [{
          from: walletAddress,
          to: USDC_ARC,
          data,
          gas: "0x186A0",
        }],
      });

      const updated = requests.map((r) =>
        r.id === req.id ? { ...r, status: "paid" as const, txHash: tx } : r
      );
      save(updated);
      setTxStatus({ id: req.id, status: "success", hash: tx });
    } catch (e: any) {
      console.error(e);
      setTxStatus({ id: req.id, status: "error" });
      setTimeout(() => setTxStatus(null), 4000);
    }
  };

  return (
    <div className="space-y-4">
      {/* Create Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold" style={{ color: "var(--text-primary)" }}>
            Payment Requests
          </h2>
          <p className="text-xs mt-0.5" style={{ color: "var(--text-secondary)" }}>
            {requests.length} request{requests.length !== 1 ? "s" : ""} · USDC on Arc
          </p>
        </div>
        <button
          onClick={() => setShowCreate(!showCreate)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-all"
          style={{
            background: showCreate ? "var(--bg-elevated)" : "linear-gradient(135deg, #3b82f6, #06b6d4)",
            color: "white",
            border: showCreate ? "1px solid var(--border-bright)" : "none",
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            {showCreate ? <path d="M18 6L6 18M6 6l12 12"/> : <path d="M12 5v14M5 12h14"/>}
          </svg>
          {showCreate ? "Cancel" : "New Request"}
        </button>
      </div>

      {/* Create Form */}
      {showCreate && (
        <div
          className="rounded-2xl p-5 space-y-4 animate-slide-up"
          style={{ background: "var(--bg-card)", border: "1px solid var(--border-bright)" }}
        >
          <h3 className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>
            New Payment Request
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-secondary)" }}>
                Recipient Address
              </label>
              <input
                type="text"
                placeholder="0x... (EVM) or wallet address"
                value={form.to}
                onChange={(e) => setForm({ ...form, to: e.target.value })}
                className="w-full px-3 py-2.5 rounded-lg text-sm font-mono outline-none transition-colors"
                style={{
                  background: "var(--bg-elevated)",
                  border: "1px solid var(--border)",
                  color: "var(--text-primary)",
                }}
                onFocus={(e) => (e.target.style.borderColor = "var(--accent-blue)")}
                onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-secondary)" }}>
                  Amount (USDC)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="0.01"
                  value={form.amount}
                  onChange={(e) => setForm({ ...form, amount: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg text-sm outline-none transition-colors"
                  style={{
                    background: "var(--bg-elevated)",
                    border: "1px solid var(--border)",
                    color: "var(--text-primary)",
                  }}
                  onFocus={(e) => (e.target.style.borderColor = "var(--accent-blue)")}
                  onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-secondary)" }}>
                  Token
                </label>
                <div
                  className="w-full px-3 py-2.5 rounded-lg text-sm flex items-center gap-2"
                  style={{ background: "var(--bg-elevated)", border: "1px solid var(--border)", color: "var(--text-primary)" }}
                >
                  <span className="w-4 h-4 rounded-full" style={{ background: "#2775CA" }} />
                  USDC
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-secondary)" }}>
                Memo (optional)
              </label>
              <input
                type="text"
                placeholder="What's this payment for?"
                value={form.memo}
                onChange={(e) => setForm({ ...form, memo: e.target.value })}
                className="w-full px-3 py-2.5 rounded-lg text-sm outline-none transition-colors"
                style={{
                  background: "var(--bg-elevated)",
                  border: "1px solid var(--border)",
                  color: "var(--text-primary)",
                }}
                onFocus={(e) => (e.target.style.borderColor = "var(--accent-blue)")}
                onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
              />
            </div>
          </div>

          <button
            onClick={createRequest}
            disabled={!form.to || !form.amount}
            className="w-full py-3 rounded-xl text-sm font-bold transition-all"
            style={{
              background: form.to && form.amount
                ? "linear-gradient(135deg, #3b82f6, #06b6d4)"
                : "var(--bg-elevated)",
              color: form.to && form.amount ? "white" : "var(--text-muted)",
            }}
          >
            Generate Payment Link
          </button>
        </div>
      )}

      {/* Request List */}
      <div className="space-y-3">
        {requests.length === 0 && (
          <div
            className="rounded-2xl p-10 text-center"
            style={{ background: "var(--bg-card)", border: "1px dashed var(--border)" }}
          >
            <p className="text-2xl mb-2">💳</p>
            <p className="text-sm font-medium" style={{ color: "var(--text-secondary)" }}>
              No payment requests yet
            </p>
            <p className="text-xs mt-1" style={{ color: "var(--text-muted)" }}>
              Create one to get a shareable payment link
            </p>
          </div>
        )}

        {requests.map((req) => (
          <div
            key={req.id}
            className="rounded-2xl p-4 space-y-3 animate-slide-up"
            style={{
              background: "var(--bg-card)",
              border: `1px solid ${req.status === "paid" ? "rgba(16,185,129,0.3)" : "var(--border)"}`,
            }}
          >
            {/* Top row */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span
                    className="px-2 py-0.5 rounded-md text-xs font-bold"
                    style={{
                      background: req.status === "paid" ? "rgba(16,185,129,0.15)" : "rgba(245,158,11,0.15)",
                      color: req.status === "paid" ? "#10b981" : "#f59e0b",
                    }}
                  >
                    {req.status === "paid" ? "✓ Paid" : "⏳ Pending"}
                  </span>
                  <span className="text-xs font-mono" style={{ color: "var(--text-muted)" }}>
                    #{req.id}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xl font-bold" style={{ color: "var(--text-primary)" }}>
                    {req.amount}
                  </span>
                  <span
                    className="px-2 py-0.5 rounded-lg text-xs font-bold"
                    style={{ background: "rgba(39,117,202,0.2)", color: "#60a5fa" }}
                  >
                    USDC
                  </span>
                </div>
                {req.memo && (
                  <p className="text-xs mt-1" style={{ color: "var(--text-secondary)" }}>
                    {req.memo}
                  </p>
                )}
                <p className="text-xs font-mono mt-1.5 truncate" style={{ color: "var(--text-muted)" }}>
                  To: {req.to.slice(0, 10)}...{req.to.slice(-6)}
                </p>
              </div>
              <p className="text-xs shrink-0" style={{ color: "var(--text-muted)" }}>
                {new Date(req.created).toLocaleDateString()}
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={() => copyLink(req)}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-colors"
                style={{
                  background: copiedId === req.id ? "rgba(16,185,129,0.15)" : "var(--bg-elevated)",
                  color: copiedId === req.id ? "#10b981" : "var(--text-secondary)",
                  border: "1px solid var(--border)",
                }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  {copiedId === req.id
                    ? <path d="M20 6L9 17l-5-5"/>
                    : <><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></>
                  }
                </svg>
                {copiedId === req.id ? "Copied!" : "Copy Link"}
              </button>

              {req.status === "pending" && (
                <>
                  <button
                    onClick={() => checkOnChain(req)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-colors"
                    style={{
                      background: "rgba(59,130,246,0.1)",
                      color: "#60a5fa",
                      border: "1px solid rgba(59,130,246,0.25)",
                    }}
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M1 4v6h6M23 20v-6h-6"/>
                      <path d="M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15"/>
                    </svg>
                    Check Chain
                  </button>

                  {walletAddress && (
                    <button
                      onClick={() => sendPayment(req)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-colors"
                      style={{
                        background: "rgba(16,185,129,0.1)",
                        color: "#10b981",
                        border: "1px solid rgba(16,185,129,0.25)",
                      }}
                    >
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="22" y1="2" x2="11" y2="13"/>
                        <polygon points="22,2 15,22 11,13 2,9"/>
                      </svg>
                      Pay Now
                    </button>
                  )}
                </>
              )}

              {req.status === "paid" && req.txHash && (
                <a
                  href={`https://explorer.arc-testnet.caldera.dev/tx/${req.txHash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-opacity hover:opacity-80"
                  style={{
                    background: "rgba(16,185,129,0.1)",
                    color: "#10b981",
                    border: "1px solid rgba(16,185,129,0.25)",
                  }}
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
                    <polyline points="15,3 21,3 21,9"/>
                    <line x1="10" y1="14" x2="21" y2="3"/>
                  </svg>
                  View Tx
                </a>
              )}
            </div>

            {/* Inline tx status */}
            {txStatus && txStatus.id === req.id && (
              <TxStatus
                status={txStatus.status}
                txHash={txStatus.hash}
                message={
                  txStatus.status === "pending" ? "Checking blockchain..."
                  : txStatus.status === "success" ? "Payment confirmed on Arc Testnet"
                  : "No payment found yet — try again later"
                }
                network="arc"
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
