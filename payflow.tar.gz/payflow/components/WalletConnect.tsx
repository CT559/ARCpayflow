"use client";

import { useState } from "react";

interface Props {
  address: string | null;
  walletType: "metamask" | "phantom" | null;
  onConnect: (address: string, type: "metamask" | "phantom") => void;
  onDisconnect: () => void;
}

const ARC_TESTNET = {
  chainId: "0x" + (2818).toString(16), // Arc Testnet chainId 2818
  chainName: "Arc Testnet",
  nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 },
  rpcUrls: ["https://rpc.arc-testnet.caldera.dev"],
  blockExplorerUrls: ["https://explorer.arc-testnet.caldera.dev"],
};

export default function WalletConnect({ address, walletType, onConnect, onDisconnect }: Props) {
  const [showMenu, setShowMenu] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const connectMetaMask = async () => {
    setLoading(true);
    setError(null);
    try {
      const eth = (window as any).ethereum;
      if (!eth) {
        setError("MetaMask not found. Please install it.");
        setShowMenu(false);
        setLoading(false);
        return;
      }
      const accounts = await eth.request({ method: "eth_requestAccounts" });
      // Try to add/switch to Arc Testnet
      try {
        await eth.request({
          method: "wallet_addEthereumChain",
          params: [ARC_TESTNET],
        });
      } catch {}
      onConnect(accounts[0], "metamask");
      setShowMenu(false);
    } catch (e: any) {
      setError(e.message || "Failed to connect MetaMask");
    }
    setLoading(false);
  };

  const connectPhantom = async () => {
    setLoading(true);
    setError(null);
    try {
      const phantom = (window as any).phantom?.ethereum || (window as any).phantom?.solana;
      const eth = (window as any).phantom?.ethereum;
      if (!phantom && !(window as any).phantom) {
        setError("Phantom not found. Please install it.");
        setShowMenu(false);
        setLoading(false);
        return;
      }
      if (eth) {
        const accounts = await eth.request({ method: "eth_requestAccounts" });
        onConnect(accounts[0], "phantom");
      } else {
        const sol = (window as any).phantom?.solana;
        const resp = await sol.connect();
        onConnect(resp.publicKey.toString(), "phantom");
      }
      setShowMenu(false);
    } catch (e: any) {
      setError(e.message || "Failed to connect Phantom");
    }
    setLoading(false);
  };

  const short = (addr: string) =>
    addr.length > 20
      ? `${addr.slice(0, 6)}...${addr.slice(-4)}`
      : addr;

  if (address) {
    return (
      <div className="relative">
        <button
          onClick={() => setShowMenu(!showMenu)}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all duration-200"
          style={{
            background: "var(--bg-elevated)",
            border: "1px solid var(--border-bright)",
            color: "var(--text-primary)",
          }}
        >
          <span className="text-base">{walletType === "phantom" ? "👻" : "🦊"}</span>
          <span className="font-mono text-xs">{short(address)}</span>
          <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor" style={{ color: "var(--text-secondary)" }}>
            <path d="M6 8L2 4h8L6 8z" />
          </svg>
        </button>

        {showMenu && (
          <div
            className="absolute right-0 top-full mt-2 w-48 rounded-xl overflow-hidden z-50 animate-slide-up"
            style={{
              background: "var(--bg-elevated)",
              border: "1px solid var(--border-bright)",
              boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
            }}
          >
            <div className="p-3 border-b" style={{ borderColor: "var(--border)" }}>
              <p className="text-xs" style={{ color: "var(--text-secondary)" }}>Connected via</p>
              <p className="text-sm font-semibold mt-0.5">
                {walletType === "phantom" ? "👻 Phantom" : "🦊 MetaMask"}
              </p>
            </div>
            <button
              onClick={() => { onDisconnect(); setShowMenu(false); }}
              className="w-full px-3 py-2.5 text-sm text-left transition-colors hover:bg-red-500/10"
              style={{ color: "#f87171" }}
            >
              Disconnect
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={() => setShowMenu(!showMenu)}
        disabled={loading}
        className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200"
        style={{
          background: "linear-gradient(135deg, #3b82f6, #06b6d4)",
          color: "white",
          opacity: loading ? 0.7 : 1,
        }}
      >
        {loading ? (
          <span className="animate-spin-custom">⟳</span>
        ) : (
          <>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
              <line x1="1" y1="10" x2="23" y2="10"/>
            </svg>
            Connect
          </>
        )}
      </button>

      {showMenu && !loading && (
        <div
          className="absolute right-0 top-full mt-2 w-52 rounded-xl overflow-hidden z-50 animate-slide-up"
          style={{
            background: "var(--bg-elevated)",
            border: "1px solid var(--border-bright)",
            boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
          }}
        >
          <div className="p-3 border-b" style={{ borderColor: "var(--border)" }}>
            <p className="text-xs font-semibold" style={{ color: "var(--text-secondary)" }}>
              Choose Wallet
            </p>
          </div>
          <button
            onClick={connectMetaMask}
            className="w-full px-3 py-3 flex items-center gap-3 text-sm transition-colors hover:bg-white/5"
            style={{ color: "var(--text-primary)" }}
          >
            <span className="text-xl">🦊</span>
            <div className="text-left">
              <p className="font-semibold">MetaMask</p>
              <p className="text-xs" style={{ color: "var(--text-secondary)" }}>EVM wallet</p>
            </div>
          </button>
          <button
            onClick={connectPhantom}
            className="w-full px-3 py-3 flex items-center gap-3 text-sm transition-colors hover:bg-white/5"
            style={{ color: "var(--text-primary)" }}
          >
            <span className="text-xl">👻</span>
            <div className="text-left">
              <p className="font-semibold">Phantom</p>
              <p className="text-xs" style={{ color: "var(--text-secondary)" }}>EVM / Solana</p>
            </div>
          </button>
        </div>
      )}

      {error && (
        <div
          className="absolute right-0 top-full mt-2 w-64 px-3 py-2.5 rounded-xl text-xs animate-slide-up"
          style={{
            background: "rgba(239,68,68,0.1)",
            border: "1px solid rgba(239,68,68,0.3)",
            color: "#f87171",
          }}
        >
          {error}
        </div>
      )}
    </div>
  );
}
