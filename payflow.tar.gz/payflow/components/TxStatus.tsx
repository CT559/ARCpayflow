"use client";

interface Props {
  status: "pending" | "success" | "error" | null;
  txHash?: string | null;
  message?: string;
  network?: "arc" | "ethereum" | "base" | "solana";
}

const EXPLORERS: Record<string, string> = {
  arc: "https://explorer.arc-testnet.caldera.dev/tx/",
  ethereum: "https://sepolia.etherscan.io/tx/",
  base: "https://sepolia.basescan.org/tx/",
  solana: "https://solscan.io/tx/",
};

const EXPLORER_NAMES: Record<string, string> = {
  arc: "Arc Explorer",
  ethereum: "Etherscan Sepolia",
  base: "BaseScan Sepolia",
  solana: "Solscan Devnet",
};

export default function TxStatus({ status, txHash, message, network = "arc" }: Props) {
  if (!status) return null;

  const explorerUrl = txHash ? `${EXPLORERS[network]}${txHash}` : null;

  const configs = {
    pending: {
      bg: "rgba(59,130,246,0.08)",
      border: "rgba(59,130,246,0.25)",
      icon: (
        <svg className="animate-spin-custom" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" strokeWidth="2">
          <path d="M21 12a9 9 0 11-6.219-8.56"/>
        </svg>
      ),
      label: "Processing",
      labelColor: "#3b82f6",
    },
    success: {
      bg: "rgba(16,185,129,0.08)",
      border: "rgba(16,185,129,0.25)",
      icon: (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2.5">
          <path d="M20 6L9 17l-5-5"/>
        </svg>
      ),
      label: "Success",
      labelColor: "#10b981",
    },
    error: {
      bg: "rgba(239,68,68,0.08)",
      border: "rgba(239,68,68,0.25)",
      icon: (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2">
          <circle cx="12" cy="12" r="10"/>
          <line x1="15" y1="9" x2="9" y2="15"/>
          <line x1="9" y1="9" x2="15" y2="15"/>
        </svg>
      ),
      label: "Failed",
      labelColor: "#ef4444",
    },
  };

  const cfg = configs[status];

  return (
    <div
      className="rounded-xl p-4 animate-slide-up"
      style={{ background: cfg.bg, border: `1px solid ${cfg.border}` }}
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5">{cfg.icon}</div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold" style={{ color: cfg.labelColor }}>
            {cfg.label}
          </p>
          {message && (
            <p className="text-xs mt-0.5" style={{ color: "var(--text-secondary)" }}>
              {message}
            </p>
          )}
          {txHash && explorerUrl && (
            <a
              href={explorerUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 mt-2 text-xs font-medium transition-opacity hover:opacity-80"
              style={{ color: cfg.labelColor }}
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
                <polyline points="15,3 21,3 21,9"/>
                <line x1="10" y1="14" x2="21" y2="3"/>
              </svg>
              View on {EXPLORER_NAMES[network]}
              <span className="font-mono opacity-60">
                {txHash.slice(0, 8)}...{txHash.slice(-6)}
              </span>
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
