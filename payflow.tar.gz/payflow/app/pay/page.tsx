"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";

function PayPageContent() {
  const params = useSearchParams();
  const to = params.get("to") || "";
  const amount = params.get("amount") || "0.01";
  const token = params.get("token") || "USDC";
  const memo = params.get("memo") || "";
  const id = params.get("id") || "";

  const [status, setStatus] = useState<"idle" | "pending" | "success" | "error">("idle");
  const [txHash, setTxHash] = useState<string | null>(null);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);

  const connectAndPay = async () => {
    const eth = (window as any).ethereum;
    if (!eth) {
      alert("Please install MetaMask to pay");
      return;
    }
    try {
      const accounts = await eth.request({ method: "eth_requestAccounts" });
      setWalletAddress(accounts[0]);
      setStatus("pending");

      const USDC_ARC = "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238";
      const selector = "0xa9059cbb";
      const paddedTo = to.replace("0x", "").padStart(64, "0");
      const bigAmt = BigInt(Math.floor(parseFloat(amount) * 1e6));
      const paddedAmt = bigAmt.toString(16).padStart(64, "0");
      const data = selector + paddedTo + paddedAmt;

      const tx = await eth.request({
        method: "eth_sendTransaction",
        params: [{ from: accounts[0], to: USDC_ARC, data, gas: "0x186A0" }],
      });

      setTxHash(tx);
      setStatus("success");
    } catch (e: any) {
      console.error(e);
      setStatus("error");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "var(--bg-primary)" }}>
      <div
        className="w-full max-w-md rounded-3xl p-8"
        style={{ background: "var(--bg-card)", border: "1px solid var(--border-bright)" }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div
            className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl mx-auto mb-4"
            style={{ background: "linear-gradient(135deg, #3b82f6, #06b6d4)" }}
          >
            💸
          </div>
          <h1 className="text-xl font-bold" style={{ color: "var(--text-primary)" }}>Payment Request</h1>
          {id && <p className="text-xs mt-1 font-mono" style={{ color: "var(--text-muted)" }}>#{id}</p>}
        </div>

        {/* Amount */}
        <div
          className="rounded-2xl p-6 text-center mb-6"
          style={{ background: "var(--bg-elevated)", border: "1px solid var(--border)" }}
        >
          <p className="text-4xl font-black" style={{ color: "var(--text-primary)" }}>
            {amount}
          </p>
          <p className="text-lg font-bold mt-1" style={{ color: "#2775CA" }}>{token}</p>
          <p className="text-xs mt-1" style={{ color: "var(--text-muted)" }}>on Arc Testnet</p>
        </div>

        {/* Details */}
        <div className="space-y-3 mb-6">
          <div className="flex justify-between text-sm">
            <span style={{ color: "var(--text-secondary)" }}>To</span>
            <span className="font-mono text-xs" style={{ color: "var(--text-primary)" }}>
              {to ? `${to.slice(0, 10)}...${to.slice(-6)}` : "—"}
            </span>
          </div>
          {memo && (
            <div className="flex justify-between text-sm">
              <span style={{ color: "var(--text-secondary)" }}>Memo</span>
              <span style={{ color: "var(--text-primary)" }}>{memo}</span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span style={{ color: "var(--text-secondary)" }}>Network</span>
            <span style={{ color: "var(--text-primary)" }}>Arc Testnet</span>
          </div>
        </div>

        {/* Status or Button */}
        {status === "success" && txHash ? (
          <div
            className="rounded-xl p-4 text-center"
            style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)" }}
          >
            <p className="text-green-400 font-bold text-lg">✓ Payment Sent!</p>
            <a
              href={`https://explorer.arc-testnet.caldera.dev/tx/${txHash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs mt-2 block hover:opacity-80"
              style={{ color: "#10b981" }}
            >
              View on Arc Explorer →
            </a>
          </div>
        ) : status === "error" ? (
          <div
            className="rounded-xl p-4 text-center"
            style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)" }}
          >
            <p className="text-red-400 font-bold">Payment failed</p>
            <button
              onClick={() => setStatus("idle")}
              className="text-xs mt-2 underline"
              style={{ color: "#f87171" }}
            >
              Try again
            </button>
          </div>
        ) : (
          <button
            onClick={connectAndPay}
            disabled={status === "pending"}
            className="w-full py-4 rounded-xl font-bold text-base transition-all"
            style={{
              background: status === "pending" ? "var(--bg-elevated)" : "linear-gradient(135deg, #3b82f6, #06b6d4)",
              color: status === "pending" ? "var(--text-muted)" : "white",
            }}
          >
            {status === "pending" ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin-custom" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 12a9 9 0 11-6.219-8.56"/>
                </svg>
                Sending...
              </span>
            ) : (
              `Pay ${amount} ${token}`
            )}
          </button>
        )}

        <p className="text-center text-xs mt-4" style={{ color: "var(--text-muted)" }}>
          Powered by PayFlow · Circle · Arc Testnet
        </p>
      </div>
    </div>
  );
}

export default function PayPage() {
  return (
    <Suspense fallback={<div style={{ background: "var(--bg-primary)" }} className="min-h-screen" />}>
      <PayPageContent />
    </Suspense>
  );
}
