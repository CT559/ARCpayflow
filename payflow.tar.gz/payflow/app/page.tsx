"use client";

import { useState, useEffect } from "react";
import PaymentRequestsTab from "@/components/PaymentRequestsTab";
import SwapTab from "@/components/SwapTab";
import BridgeTab from "@/components/BridgeTab";
import WalletConnect from "@/components/WalletConnect";

type Tab = "payments" | "swap" | "bridge";

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>("payments");
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [walletType, setWalletType] = useState<"metamask" | "phantom" | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Check if wallet was previously connected
    const saved = sessionStorage.getItem("payflow_wallet");
    if (saved) {
      try {
        const { address, type } = JSON.parse(saved);
        setWalletAddress(address);
        setWalletType(type);
      } catch {}
    }
  }, []);

  const handleConnect = (address: string, type: "metamask" | "phantom") => {
    setWalletAddress(address);
    setWalletType(type);
    sessionStorage.setItem("payflow_wallet", JSON.stringify({ address, type }));
  };

  const handleDisconnect = () => {
    setWalletAddress(null);
    setWalletType(null);
    sessionStorage.removeItem("payflow_wallet");
  };

  const tabs: { id: Tab; label: string; icon: string; desc: string }[] = [
    { id: "payments", label: "Payment Requests", icon: "💳", desc: "Create & track" },
    { id: "swap", label: "Swap", icon: "🔄", desc: "USDC ↔ EURC" },
    { id: "bridge", label: "Bridge", icon: "🌉", desc: "→ Arc Testnet" },
  ];

  if (!mounted) return null;

  return (
    <div className="min-h-screen" style={{ background: "var(--bg-primary)" }}>
      {/* Background grid */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(59,130,246,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(59,130,246,0.03) 1px, transparent 1px)
          `,
          backgroundSize: "40px 40px",
        }}
      />

      {/* Ambient glow */}
      <div
        className="fixed top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at center top, rgba(59,130,246,0.08) 0%, transparent 70%)",
        }}
      />

      <div className="relative max-w-2xl mx-auto px-4 py-6">
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
              style={{ background: "linear-gradient(135deg, #3b82f6, #06b6d4)" }}
            >
              💸
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>
                PayFlow
              </h1>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 pulse-dot" />
                <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
                  Arc Testnet
                </span>
              </div>
            </div>
          </div>

          <WalletConnect
            address={walletAddress}
            walletType={walletType}
            onConnect={handleConnect}
            onDisconnect={handleDisconnect}
          />
        </header>

        {/* Tabs */}
        <div
          className="flex gap-1 p-1 rounded-xl mb-6"
          style={{ background: "var(--bg-secondary)", border: "1px solid var(--border)" }}
        >
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex-1 flex flex-col items-center gap-0.5 py-2.5 px-2 rounded-lg transition-all duration-200 text-center"
              style={{
                background: activeTab === tab.id
                  ? "var(--bg-card)"
                  : "transparent",
                border: activeTab === tab.id
                  ? "1px solid var(--border-bright)"
                  : "1px solid transparent",
                color: activeTab === tab.id ? "var(--text-primary)" : "var(--text-secondary)",
                boxShadow: activeTab === tab.id ? "0 0 12px rgba(59,130,246,0.1)" : "none",
              }}
            >
              <span className="text-base">{tab.icon}</span>
              <span className="text-xs font-semibold leading-tight">{tab.label}</span>
              <span className="text-xs opacity-60 leading-tight hidden sm:block">{tab.desc}</span>
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="animate-slide-up" key={activeTab}>
          {activeTab === "payments" && (
            <PaymentRequestsTab walletAddress={walletAddress} />
          )}
          {activeTab === "swap" && (
            <SwapTab walletAddress={walletAddress} />
          )}
          {activeTab === "bridge" && (
            <BridgeTab walletAddress={walletAddress} />
          )}
        </div>

        {/* Footer */}
        <footer className="mt-8 text-center">
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            PayFlow · Circle App Kit · Arc Testnet
          </p>
        </footer>
      </div>
    </div>
  );
}
